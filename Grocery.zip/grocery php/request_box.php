<?php
	$host='localhost';
	$uname='root';
	$pwd='';
	$db="grocery";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");	 
	$name=$_REQUEST['name'];
	$discription=$_REQUEST['discription'];
	$required=$_REQUEST['required'];
	
	$flag['code']=0;

	if($r=mysql_query("insert into request values('$name','$discription','$required')",$con))
	{
		$flag['code']=1;
		
	}
	print(json_encode($flag));
	mysql_close($con);
?>