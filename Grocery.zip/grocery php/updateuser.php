<?php
   $hostname_localhost ="localhost";
    $database_localhost ="grocery";
    $username_localhost ="root";
    $password_localhost ="";
    $localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
    or
    trigger_error(mysql_error(),E_USER_ERROR);
  mysql_select_db($database_localhost, $localhost);
$username=$_REQUEST['username'];
$address=$_REQUEST['address'];
$mobile=$_REQUEST['mobile'];
$email=$_REQUEST['email'];
	$flag['code']=0;
	if($r=mysql_query("UPDATE users SET username='$username',address='$address',mobile='$mobile' WHERE email ='$email'",$localhost))
	{
		$flag['code']=1;
	}
	 
	print(json_encode($flag));
	mysql_close($localhost);
?>