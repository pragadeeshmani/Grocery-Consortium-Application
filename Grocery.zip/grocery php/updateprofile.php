<?php
   $hostname_localhost ="localhost";
    $database_localhost ="grocery";
    $username_localhost ="root";
    $password_localhost ="";
    $localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
    or
    trigger_error(mysql_error(),E_USER_ERROR);
  mysql_select_db($database_localhost, $localhost);
$amount=$_REQUEST['amount'];
	$flag['code']=0;
	if($r=mysql_query("UPDATE bank SET amount='$amount'",$localhost))
	{
		$flag['code']=1;
	}
	 
	print(json_encode($flag));
	mysql_close($localhost);
?>