<?php
	$host='localhost';
	$uname='root';
	$pwd='';
	$db="grocery";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");	 
	$name=$_REQUEST['name'];
	$price=$_REQUEST['price'];
	
	$flag['code']=0;

	if($r=mysql_query("insert into grocerypay values('$name','$price')",$con))
	{
		$flag['code']=1;
		
	}
	print(json_encode($flag));
	mysql_close($con);
?>