<?php
    $hostname_localhost ="localhost";
    $database_localhost ="grocery";
    $username_localhost ="root";
    $password_localhost ="";
    $localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
    or
    trigger_error(mysql_error(),E_USER_ERROR);
  mysql_select_db($database_localhost, $localhost);
$username = $_POST['username'];
$i=mysql_query("select * from users where email='".$username."'");
$num_rows = mysql_num_rows($i);
while($row = mysql_fetch_array($i))
{
$r[]=$row;
$check=$row['name'];
}

if($check==NULL)
{
$r[$num_rows]="Record is not available";
print(json_encode($r));
}
else
{
$r[$num_rows]="success";
print(json_encode($r));
}

mysql_close($localhost);
?>