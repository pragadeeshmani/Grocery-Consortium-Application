<?php	
	$con = mysql_connect('localhost','root','');
	if (!$con)
  	{
  	die('Could not connect to Server ' . mysql_error());
  	}
  	$db_selected = mysql_select_db("grocery", $con);
?> 