<?php
	$host='localhost';
	$uname='root';
	$pwd='';
	$db="grocery";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");	 
	$name=$_REQUEST['name'];
	$details=$_REQUEST['details'];
	$price=$_REQUEST['price'];
	$categories=$_REQUEST['categories'];
	$images=$_REQUEST['pic'];
	$decoded = base64_decode($images);
	
	$flag['code']=0;

	if($r=mysql_query("insert into add_products values('$name','$details','$price','$categories','$images')",$con))
	{
		$flag['code']=1;
		
	}
	print(json_encode($flag));
	mysql_close($con);
?>