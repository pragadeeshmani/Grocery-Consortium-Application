<?php
	$host='localhost';
	$uname='root';
	$pwd='';
	$db="grocery";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");	 
	$list_name=$_REQUEST['list_name'];
	$flag['code']=0;

	if($r=mysql_query("insert into categories values('null','$list_name')",$con))
	{
		$flag['code']=1;
		
	}
	print(json_encode($flag));
	mysql_close($con);
?>