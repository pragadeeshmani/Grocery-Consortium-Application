<?php
	$host='localhost';
	$uname='root';
	$pwd='';
	$db="grocery";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");	 
	$name=$_REQUEST['name'];
	$email=$_REQUEST['email'];
	$password=$_REQUEST['password'];
	$address=$_REQUEST['address'];
	$mobile=$_REQUEST['mobile'];

	$flag['code']=0;

	if($r=mysql_query("insert into users values('$name','$email','$password','$address','$mobile')",$con))
	{
		$flag['code']=1;
		
	}
	print(json_encode($flag));
	mysql_close($con);
?>