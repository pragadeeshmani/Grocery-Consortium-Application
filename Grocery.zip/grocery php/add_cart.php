<?php
	$host='localhost';
	$uname='root';
	$pwd='';
	$db="Grocery";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$name=$_REQUEST['name'];
	$email=$_REQUEST['email'];
	$quantity=$_REQUEST['quantity'];
	$price=$_REQUEST['price'];
	$flag['code']=0;

	if($r=mysql_query("insert into cart values('$name','$email','$quantity','$price') ",$con))
	{
		$flag['code']=1;
		echo"hi";
	}

	print(json_encode($flag));
	mysql_close($con);
?>