package com.example.grocery.grocery;

import android.app.Activity;
import android.os.Bundle;

public class Admin_details extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
	      super.onCreate(savedInstanceState);
	      setContentView(R.layout.admin_details);
	}
}
