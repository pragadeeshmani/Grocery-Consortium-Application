package com.example.grocery.grocery;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by priya on 19-03-2017.
 */
public class userdetails_display extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userdetails_display);


    }
}